#ifndef __IRQ_RF_H
#define __IRQ_RF_H	 
#include "HAL_conf.h"

void IRQ_RF(void);
char IsIrqEnabled(void); //porting api

		 				    
#endif
