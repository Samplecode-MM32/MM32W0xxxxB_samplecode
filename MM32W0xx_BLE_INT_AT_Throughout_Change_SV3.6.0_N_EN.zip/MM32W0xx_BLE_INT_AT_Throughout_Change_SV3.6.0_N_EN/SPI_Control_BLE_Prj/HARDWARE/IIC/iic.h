#ifndef __LED_H
#define __LED_H
#include "HAL_conf.h"

void IIC_Init(I2C_TypeDef *I2Cx);


#endif
